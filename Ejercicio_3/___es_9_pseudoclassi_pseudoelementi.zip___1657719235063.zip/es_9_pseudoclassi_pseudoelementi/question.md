
- Add to the first letter of the first paragraph the following properties:

```css
{
	float: left;
	color: darkred;
	border: 3px ridge darkgoldenrod;
	padding: 16px;
	background-color: gold;
	margin: 8px;
}
```

 - Add to the `blockquote` the quotation marks at the start and the end of the text.
 - The link at the end of the page should have a hover effect. And it should have a different color if it is already visited.
