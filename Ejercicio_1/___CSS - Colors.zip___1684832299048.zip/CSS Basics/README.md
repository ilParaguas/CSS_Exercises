1. Create a simple HTML file with an h1 and a P tag.
2. Create a CSS file and write a rule that gives the color 'blue' to the h1 text.
3. Write a rule that gives the color 'lightgray' to the body background
4. Write a rule that gives a font size of 20px to the p tag.
5. Write a rule that gives Arial, sans-serif as font family to all the texts